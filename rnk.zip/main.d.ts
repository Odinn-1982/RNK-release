/**
 * Unhallowed Metropolis - A Neo-Victorian Horror RPG System for Foundry VTT
 *
 * Based on Unhallowed Metropolis Revised by Atomic Overmind Press
 * System implementation for Foundry VTT V13
 */
