export declare class LandingPage3D {
    private renderer;
    private scene;
    private camera;
    private container;
    private animationId;
    private cube;
    private model;
    constructor();
    private createEnvironment;
    private loadHeroModel;
    private createHeroObject;
    private onWindowResize;
    private animate;
    destroy(): void;
}
