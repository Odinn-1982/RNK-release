const c = {
  /**
   * Core Attributes - The six fundamental character attributes
   * Each rated 1-5 for humans (some creatures may exceed this)
   */
  attributes: {
    vitality: "UM.Attributes.Vitality",
    coordination: "UM.Attributes.Coordination",
    wit: "UM.Attributes.Wit",
    intellect: "UM.Attributes.Intellect",
    will: "UM.Attributes.Will",
    charm: "UM.Attributes.Charm"
  },
  /**
   * Attribute abbreviations for compact display
   */
  attributeAbbreviations: {
    vitality: "UM.Attributes.VitalityAbbr",
    coordination: "UM.Attributes.CoordinationAbbr",
    wit: "UM.Attributes.WitAbbr",
    intellect: "UM.Attributes.IntellectAbbr",
    will: "UM.Attributes.WillAbbr",
    charm: "UM.Attributes.CharmAbbr"
  },
  /**
   * Derived Statistics - Calculated from attributes
   */
  derivedStats: {
    health: "UM.Derived.Health",
    // Vitality × 2 + 10
    mentalHealth: "UM.Derived.MentalHealth",
    // Will × 2 + 10
    initiative: "UM.Derived.Initiative",
    // Wit + Coordination
    actions: "UM.Derived.Actions",
    // Based on Coordination
    movement: "UM.Derived.Movement",
    // Based on Coordination
    corruptionThreshold: "UM.Derived.CorruptionThreshold"
    // Will × 2
  },
  /**
   * Skills organized by governing attribute
   */
  skills: {
    // Vitality-based skills
    athletics: { label: "UM.Skills.Athletics", attribute: "vitality" },
    brawl: { label: "UM.Skills.Brawl", attribute: "vitality" },
    endurance: { label: "UM.Skills.Endurance", attribute: "vitality" },
    // Coordination-based skills
    concentration: { label: "UM.Skills.Concentration", attribute: "coordination" },
    drive: { label: "UM.Skills.Drive", attribute: "coordination" },
    firearms: { label: "UM.Skills.Firearms", attribute: "coordination" },
    larceny: { label: "UM.Skills.Larceny", attribute: "coordination" },
    melee: { label: "UM.Skills.Melee", attribute: "coordination" },
    stealth: { label: "UM.Skills.Stealth", attribute: "coordination" },
    // Wit-based skills
    animalHandling: { label: "UM.Skills.AnimalHandling", attribute: "wit" },
    awareness: { label: "UM.Skills.Awareness", attribute: "wit" },
    empathy: { label: "UM.Skills.Empathy", attribute: "wit" },
    gambling: { label: "UM.Skills.Gambling", attribute: "wit" },
    // Intellect-based skills
    academics: { label: "UM.Skills.Academics", attribute: "intellect" },
    bureauracy: { label: "UM.Skills.Bureaucracy", attribute: "intellect" },
    criminology: { label: "UM.Skills.Criminology", attribute: "intellect" },
    demolitions: { label: "UM.Skills.Demolitions", attribute: "intellect" },
    engineering: { label: "UM.Skills.Engineering", attribute: "intellect" },
    medicine: { label: "UM.Skills.Medicine", attribute: "intellect" },
    occult: { label: "UM.Skills.Occult", attribute: "intellect" },
    politics: { label: "UM.Skills.Politics", attribute: "intellect" },
    science: { label: "UM.Skills.Science", attribute: "intellect" },
    survival: { label: "UM.Skills.Survival", attribute: "intellect" },
    // Will-based skills
    intimidation: { label: "UM.Skills.Intimidation", attribute: "will" },
    meditation: { label: "UM.Skills.Meditation", attribute: "will" },
    // Charm-based skills
    artistry: { label: "UM.Skills.Artistry", attribute: "charm" },
    etiquette: { label: "UM.Skills.Etiquette", attribute: "charm" },
    expression: { label: "UM.Skills.Expression", attribute: "charm" },
    leadership: { label: "UM.Skills.Leadership", attribute: "charm" },
    negotiation: { label: "UM.Skills.Negotiation", attribute: "charm" },
    seduction: { label: "UM.Skills.Seduction", attribute: "charm" },
    streetwise: { label: "UM.Skills.Streetwise", attribute: "charm" },
    subterfuge: { label: "UM.Skills.Subterfuge", attribute: "charm" }
  },
  /**
   * Character Callings - Professional backgrounds
   */
  callings: {
    aristocrat: "UM.Callings.Aristocrat",
    criminal: "UM.Callings.Criminal",
    deathwatchSoldier: "UM.Callings.DeathwatchSoldier",
    detective: "UM.Callings.Detective",
    dhampir: "UM.Callings.Dhampir",
    doctor: "UM.Callings.Doctor",
    medium: "UM.Callings.Medium",
    mourner: "UM.Callings.Mourner",
    promethean: "UM.Callings.Promethean",
    undertaker: "UM.Callings.Undertaker",
    soldier: "UM.Callings.Soldier",
    inventor: "UM.Callings.Inventor",
    clergy: "UM.Callings.Clergy",
    courtesan: "UM.Callings.Courtesan",
    journalist: "UM.Callings.Journalist",
    alchemist: "UM.Callings.Alchemist",
    servant: "UM.Callings.Servant",
    psychic: "UM.Callings.Psychic",
    entertainer: "UM.Callings.Entertainer"
  },
  /**
   * Social Classes
   */
  socialClasses: {
    gutter: "UM.SocialClass.Gutter",
    working: "UM.SocialClass.Working",
    middle: "UM.SocialClass.Middle",
    upperMiddle: "UM.SocialClass.UpperMiddle",
    upper: "UM.SocialClass.Upper",
    aristocracy: "UM.SocialClass.Aristocracy"
  },
  /**
   * Corruption Types
   */
  corruptionTypes: {
    physical: "UM.Corruption.Physical",
    mental: "UM.Corruption.Mental",
    desire: "UM.Corruption.Desire",
    drive: "UM.Corruption.Drive"
  },
  /**
   * Afflictions - Physical corruption manifestations
   */
  afflictionSeverity: {
    minor: "UM.Affliction.Minor",
    moderate: "UM.Affliction.Moderate",
    severe: "UM.Affliction.Severe"
  },
  /**
   * Item Types
   */
  itemTypes: {
    weapon: "UM.ItemTypes.Weapon",
    armor: "UM.ItemTypes.Armor",
    equipment: "UM.ItemTypes.Equipment",
    quality: "UM.ItemTypes.Quality",
    affliction: "UM.ItemTypes.Affliction",
    disorder: "UM.ItemTypes.Disorder",
    calling: "UM.ItemTypes.Calling",
    talent: "UM.ItemTypes.Talent",
    psychicPower: "UM.ItemTypes.PsychicPower"
  },
  /**
   * Psychic Devotions
   */
  psychicDevotions: {
    empathy: "UM.Devotions.Empathy",
    magnetism: "UM.Devotions.Magnetism",
    necromancy: "UM.Devotions.Necromancy",
    clairvoyance: "UM.Devotions.Clairvoyance",
    psychokinesis: "UM.Devotions.Psychokinesis",
    telepathy: "UM.Devotions.Telepathy"
  },
  /**
   * Weapon Types
   */
  weaponTypes: {
    melee: "UM.WeaponTypes.Melee",
    ranged: "UM.WeaponTypes.Ranged",
    thrown: "UM.WeaponTypes.Thrown"
  },
  /**
   * Damage Types
   */
  damageTypes: {
    bashing: "UM.DamageTypes.Bashing",
    lethal: "UM.DamageTypes.Lethal",
    aggravated: "UM.DamageTypes.Aggravated"
  },
  /**
   * Hit Locations
   */
  hitLocations: {
    head: { label: "UM.HitLocations.Head", range: [1, 1] },
    torso: { label: "UM.HitLocations.Torso", range: [2, 4] },
    rightArm: { label: "UM.HitLocations.RightArm", range: [5, 5] },
    leftArm: { label: "UM.HitLocations.LeftArm", range: [6, 6] },
    rightLeg: { label: "UM.HitLocations.RightLeg", range: [7, 8] },
    leftLeg: { label: "UM.HitLocations.LeftLeg", range: [9, 10] }
  },
  /**
   * Roll result thresholds
   */
  rollThresholds: {
    criticalFailure: 4,
    // Both dice show 2 or less
    failure: 11,
    // Below target number
    success: 0,
    // Meet or exceed TN
    exceptionalSuccess: 5,
    // Exceed TN by 5+
    criticalSuccess: 10
    // Exceed TN by 10+ or double 10s
  },
  /**
   * Action economy constants
   */
  actionCosts: {
    attack: 1,
    move: 1,
    aim: 1,
    dodge: 1,
    parry: 1,
    reload: 1,
    useItem: 1
  },
  /**
   * Default target numbers
   */
  targetNumbers: {
    easy: 7,
    average: 11,
    challenging: 15,
    difficult: 19,
    heroic: 23,
    legendary: 27
  },
  /**
   * Actor types for the system
   */
  actorTypes: ["character", "npc", "animate", "vampire", "creature"],
  /**
   * Currency denominations (Victorian-era)
   */
  currency: {
    pounds: "UM.Currency.Pounds",
    shillings: "UM.Currency.Shillings",
    pence: "UM.Currency.Pence"
  }
};
class b extends ActorSheet {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["unhallowed-metropolis", "sheet", "actor", "character"],
      template: "systems/unhallowed-metropolis/templates/actors/character-sheet.hbs",
      width: 720,
      height: 800,
      tabs: [
        { navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "attributes" }
      ],
      resizable: !0,
      scrollY: [".sheet-body"]
    });
  }
  /**
   * Prepare data for the template
   */
  getData(e) {
    const t = super.getData(e);
    t.config = c;
    const a = this.actor;
    return t.system = a.system, t.flags = a.flags, t.attributes = this._prepareAttributes(t.system.attributes), t.skillsByAttribute = this._prepareSkills(t.system.skills), t.items = this._prepareItems(a.items), t.healthPercent = Math.round(t.system.derived.health.value / t.system.derived.health.max * 100), t.mentalPercent = Math.round(t.system.derived.mentalHealth.value / t.system.derived.mentalHealth.max * 100), t.physicalCorruptionPercent = Math.round(t.system.corruption.physical.value / t.system.corruption.physical.threshold * 100), t.mentalCorruptionPercent = Math.round(t.system.corruption.mental.value / t.system.corruption.mental.threshold * 100), t;
  }
  /**
   * Prepare attributes data for the template
   */
  _prepareAttributes(e) {
    const t = [];
    for (const [a, i] of Object.entries(c.attributes)) {
      const s = e[a] || { value: 2, modifier: 0 };
      t.push({
        key: a,
        label: game.i18n.localize(i),
        abbr: game.i18n.localize(c.attributeAbbreviations[a]),
        value: s.value,
        modifier: s.modifier
      });
    }
    return t;
  }
  /**
   * Prepare skills organized by governing attribute
   */
  _prepareSkills(e) {
    const t = {
      vitality: [],
      coordination: [],
      wit: [],
      intellect: [],
      will: [],
      charm: []
    };
    for (const [a, i] of Object.entries(c.skills)) {
      const s = i, r = e[a] || { value: 0, specializations: [] };
      t[s.attribute].push({
        key: a,
        label: game.i18n.localize(s.label),
        value: r.value,
        specializations: r.specializations || [],
        attribute: s.attribute
      });
    }
    return t;
  }
  /**
   * Organize items by type for the sheet
   */
  _prepareItems(e) {
    const t = {
      weapons: [],
      armor: [],
      equipment: [],
      qualities: [],
      afflictions: [],
      disorders: [],
      talents: [],
      psychicPowers: [],
      callings: []
    };
    for (const a of e) {
      const i = a;
      switch (i.type) {
        case "weapon":
          t.weapons.push(i);
          break;
        case "armor":
          t.armor.push(i);
          break;
        case "equipment":
          t.equipment.push(i);
          break;
        case "quality":
          t.qualities.push(i);
          break;
        case "affliction":
          t.afflictions.push(i);
          break;
        case "disorder":
          t.disorders.push(i);
          break;
        case "talent":
          t.talents.push(i);
          break;
        case "psychicPower":
          t.psychicPowers.push(i);
          break;
        case "calling":
          t.callings.push(i);
          break;
        default:
          t.equipment.push(i);
      }
    }
    return t;
  }
  /**
   * Activate event listeners
   */
  activateListeners(e) {
    if (super.activateListeners(e), !!this.isEditable && (e.find(".attribute-roll").on("click", this._onAttributeRoll.bind(this)), e.find(".skill-roll").on("click", this._onSkillRoll.bind(this)), e.find(".attribute-dot").on("click", this._onAttributeDotClick.bind(this)), e.find(".skill-dot").on("click", this._onSkillDotClick.bind(this)), e.find(".health-bar").on("click", this._onHealthClick.bind(this)), e.find(".mental-bar").on("click", this._onMentalClick.bind(this)), e.find(".corruption-pip").on("click", this._onCorruptionClick.bind(this)), e.find(".item-create").on("click", this._onItemCreate.bind(this)), e.find(".item-edit").on("click", this._onItemEdit.bind(this)), e.find(".item-delete").on("click", this._onItemDelete.bind(this)), e.find(".item-roll").on("click", this._onItemRoll.bind(this)), e.find(".power-activate").on("click", this._onPowerActivate.bind(this)), this.actor.isOwner)) {
      const t = (a) => this._onDragStart(a);
      e.find(".item").each((a, i) => {
        i.setAttribute("draggable", "true"), i.addEventListener("dragstart", t, !1);
      });
    }
  }
  /**
   * Handle attribute roll clicks
   */
  async _onAttributeRoll(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.attribute;
    a && await this.actor.rollAttribute(a, { targetNumber: 11 });
  }
  /**
   * Handle skill roll clicks
   */
  async _onSkillRoll(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.skill;
    a && await this.actor.rollSkill(a, { targetNumber: 11 });
  }
  /**
   * Handle clicking on attribute dots to change value
   */
  async _onAttributeDotClick(e) {
    e.preventDefault();
    const t = e.currentTarget, a = parseInt(t.dataset.value || "1"), s = $(t).closest(".attribute-row").data("attribute");
    s && await this.actor.update({
      [`system.attributes.${s}.value`]: a
    });
  }
  /**
   * Handle clicking on skill dots to change value
   */
  async _onSkillDotClick(e) {
    e.preventDefault();
    const t = e.currentTarget, a = parseInt(t.dataset.value || "0"), s = $(t).closest(".skill-row").data("skill");
    s && await this.actor.update({
      [`system.skills.${s}.value`]: a
    });
  }
  /**
   * Handle health bar clicks
   */
  async _onHealthClick(e) {
    e.preventDefault();
    const a = this.actor.system.derived.health.max, i = e.currentTarget.getBoundingClientRect(), s = (e.clientX - i.left) / i.width, r = Math.round(s * a);
    await this.actor.update({
      "system.derived.health.value": Math.max(0, Math.min(a, r))
    });
  }
  /**
   * Handle mental health bar clicks
   */
  async _onMentalClick(e) {
    e.preventDefault();
    const a = this.actor.system.derived.mentalHealth.max, i = e.currentTarget.getBoundingClientRect(), s = (e.clientX - i.left) / i.width, r = Math.round(s * a);
    await this.actor.update({
      "system.derived.mentalHealth.value": Math.max(0, Math.min(a, r))
    });
  }
  /**
   * Handle corruption pip clicks
   */
  async _onCorruptionClick(e) {
    e.preventDefault();
    const t = e.currentTarget, a = parseInt(t.dataset.index || "0"), s = $(t).closest(".corruption-track").data("type"), n = this.actor.system.corruption[s].value, o = a < n ? a : a + 1;
    await this.actor.update({
      [`system.corruption.${s}.value`]: o
    });
  }
  /**
   * Handle creating a new item
   */
  async _onItemCreate(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.type || "equipment", i = {
      name: game.i18n.format("UM.Item.New", { type: game.i18n.localize(`UM.ItemTypes.${a.charAt(0).toUpperCase() + a.slice(1)}`) }),
      type: a
    };
    await Item.create(i, { parent: this.actor });
  }
  /**
   * Handle editing an item
   */
  _onItemEdit(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && i.sheet?.render(!0);
  }
  /**
   * Handle deleting an item
   */
  async _onItemDelete(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && await i.delete();
  }
  /**
   * Handle rolling an item (e.g., weapon attack)
   */
  async _onItemRoll(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && typeof i.roll == "function" && await i.roll();
  }
  /**
   * Handle psychic power activation
   */
  async _onPowerActivate(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    if (!i) return;
    const s = i.name, r = i.system?.discipline || "Unknown", n = i.system?.cost || 0, o = i.system?.rules || i.system?.description || "", u = `
      <div class="um-power-card">
        <div class="power-header">
          <img src="${i.img}" alt="${s}" width="36" height="36"/>
          <div class="power-title">
            <h3>${s}</h3>
            <span class="power-discipline">${r}</span>
          </div>
        </div>
        <div class="power-details">
          ${n ? `<p><strong>Cost:</strong> ${n} Instability</p>` : ""}
          ${o ? `<div class="power-rules">${o}</div>` : ""}
        </div>
      </div>
    `;
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: u,
      flavor: `${this.actor.name} activates a psychic power`
    });
  }
}
class g extends ActorSheet {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["unhallowed-metropolis", "sheet", "actor", "npc"],
      template: "systems/unhallowed-metropolis/templates/actors/npc-sheet.hbs",
      width: 520,
      height: 480,
      tabs: [
        { navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "stats" }
      ],
      resizable: !0
    });
  }
  getData(e) {
    const t = super.getData(e);
    t.config = c;
    const a = this.actor;
    t.system = a.system, t.flags = a.flags, t.items = {
      weapons: [],
      abilities: [],
      equipment: []
    };
    for (const i of a.items) {
      const s = i;
      s.type === "weapon" ? t.items.weapons.push(s) : s.type === "talent" || s.type === "quality" ? t.items.abilities.push(s) : t.items.equipment.push(s);
    }
    return t;
  }
  activateListeners(e) {
    super.activateListeners(e), this.isEditable && (e.find(".attribute-roll").on("click", this._onAttributeRoll.bind(this)), e.find(".item-create").on("click", this._onItemCreate.bind(this)), e.find(".item-edit").on("click", this._onItemEdit.bind(this)), e.find(".item-delete").on("click", this._onItemDelete.bind(this)), e.find(".item-roll").on("click", this._onItemRoll.bind(this)));
  }
  async _onAttributeRoll(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.attribute;
    a && await this.actor.rollAttribute(a, { targetNumber: 11 });
  }
  async _onItemCreate(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.type || "equipment", i = {
      name: `New ${a}`,
      type: a
    };
    await Item.create(i, { parent: this.actor });
  }
  _onItemEdit(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && i.sheet?.render(!0);
  }
  async _onItemDelete(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && await i.delete();
  }
  async _onItemRoll(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && typeof i.roll == "function" && await i.roll();
  }
}
class y extends ActorSheet {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["unhallowed-metropolis", "sheet", "actor", "creature"],
      template: "systems/unhallowed-metropolis/templates/actors/creature-sheet.hbs",
      width: 560,
      height: 520,
      tabs: [
        { navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "stats" }
      ],
      resizable: !0
    });
  }
  getData(e) {
    const t = super.getData(e);
    t.config = c;
    const a = this.actor;
    t.system = a.system, t.flags = a.flags, t.items = {
      weapons: [],
      abilities: [],
      equipment: []
    };
    for (const i of a.items) {
      const s = i;
      s.type === "weapon" ? t.items.weapons.push(s) : s.type === "talent" || s.type === "quality" ? t.items.abilities.push(s) : t.items.equipment.push(s);
    }
    return t;
  }
  activateListeners(e) {
    super.activateListeners(e), this.isEditable && (e.find(".attribute-roll").on("click", this._onAttributeRoll.bind(this)), e.find(".item-create").on("click", this._onItemCreate.bind(this)), e.find(".item-edit").on("click", this._onItemEdit.bind(this)), e.find(".item-delete").on("click", this._onItemDelete.bind(this)), e.find(".item-roll").on("click", this._onItemRoll.bind(this)));
  }
  async _onAttributeRoll(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.attribute;
    a && await this.actor.rollAttribute(a, { targetNumber: 11 });
  }
  async _onItemCreate(e) {
    e.preventDefault();
    const a = e.currentTarget.dataset.type || "equipment", i = {
      name: `New ${a}`,
      type: a
    };
    await Item.create(i, { parent: this.actor });
  }
  _onItemEdit(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && i.sheet?.render(!0);
  }
  async _onItemDelete(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && await i.delete();
  }
  async _onItemRoll(e) {
    e.preventDefault();
    const a = $(e.currentTarget).closest(".item").data("item-id"), i = this.actor.items.get(a);
    i && typeof i.roll == "function" && await i.roll();
  }
}
class d extends Actor {
  /**
   * Prepare base data - called before embedded documents
   */
  prepareBaseData() {
    super.prepareBaseData();
    const t = this.system;
    this._initializeData(t);
  }
  /**
   * Prepare derived data - called after embedded documents
   */
  prepareDerivedData() {
    super.prepareDerivedData();
    const e = this, t = e.system, a = e.type;
    a === "character" || a === "npc" ? this._prepareCharacterData(t) : (a === "animate" || a === "vampire" || a === "creature") && this._prepareCreatureData(t, a);
  }
  /**
   * Initialize the data structure for a new actor
   */
  _initializeData(e) {
    e.attributes = e.attributes || {};
    for (const t of Object.keys(c.attributes))
      e.attributes[t] = e.attributes[t] || { value: 2, modifier: 0 };
    e.skills = e.skills || {};
    for (const t of Object.keys(c.skills))
      e.skills[t] = e.skills[t] || { value: 0, specializations: [] };
    e.derived = e.derived || {
      health: { value: 14, max: 14, temp: 0 },
      mentalHealth: { value: 14, max: 14, temp: 0 },
      initiative: 4,
      actions: 2,
      movement: 5,
      corruptionThreshold: 4
    }, e.corruption = e.corruption || {
      physical: { value: 0, threshold: 4 },
      mental: { value: 0, threshold: 4 },
      desire: "",
      drive: ""
    }, e.details = e.details || {
      calling: "",
      socialClass: "",
      background: "",
      birthplace: "",
      age: 25,
      gender: "",
      height: "",
      weight: "",
      appearance: "",
      notes: ""
    }, e.currency = e.currency || {
      pounds: 0,
      shillings: 0,
      pence: 0
    };
  }
  /**
   * Calculate derived statistics for characters
   */
  _prepareCharacterData(e) {
    const t = e.attributes, a = (t.vitality?.value || 2) * 2 + 10;
    e.derived.health.max = a, e.derived.health.value > a && (e.derived.health.value = a);
    const i = (t.will?.value || 2) * 2 + 10;
    e.derived.mentalHealth.max = i, e.derived.mentalHealth.value > i && (e.derived.mentalHealth.value = i), e.derived.initiative = (t.wit?.value || 2) + (t.coordination?.value || 2);
    const s = t.coordination?.value || 2;
    s <= 1 ? e.derived.actions = 1 : s <= 3 ? e.derived.actions = 2 : s <= 4 ? e.derived.actions = 3 : e.derived.actions = 4, e.derived.movement = s + 3;
    const r = t.will?.value || 2;
    e.derived.corruptionThreshold = r * 2, e.corruption.physical.threshold = r * 2, e.corruption.mental.threshold = r * 2;
  }
  /**
   * Calculate derived statistics for creatures (animates, vampires, etc.)
   */
  _prepareCreatureData(e, t) {
    const a = e.attributes, i = t === "vampire" ? 3 : 2.5, s = Math.floor((a.vitality?.value || 3) * i + 10);
    e.derived.health.max = s, e.derived.health.value > s && (e.derived.health.value = s);
    const r = t === "vampire" ? 3 : 2, n = Math.floor((a.will?.value || 3) * r + 10);
    e.derived.mentalHealth.max = n, e.derived.mentalHealth.value > n && (e.derived.mentalHealth.value = n), e.derived.initiative = (a.wit?.value || 2) + (a.coordination?.value || 2);
    const o = a.coordination?.value || 2;
    o <= 1 ? e.derived.actions = 1 : o <= 3 ? e.derived.actions = 2 : o <= 4 ? e.derived.actions = 3 : e.derived.actions = 4, t === "vampire" && (e.bloodPool = e.bloodPool || { value: 10, max: 10 }, e.bloodPool.max = (a.vitality?.value || 3) * 3 + 5), e.derived.movement = (a.coordination?.value || 2) + 4;
  }
  /**
   * Roll an attribute check
   */
  async rollAttribute(e, t = {}) {
    const a = this.system, i = a.attributes[e]?.value || 2, s = a.attributes[e]?.modifier || 0, r = t.bonus || 0, n = `2d10 + ${i} + ${s} + ${r}`, o = new Roll(n);
    return await o.evaluate(), await this._createRollMessage(o, {
      title: game.i18n.localize(c.attributes[e]),
      targetNumber: t.targetNumber
    }), o;
  }
  /**
   * Roll a skill check
   */
  async rollSkill(e, t = {}) {
    const a = this.system, i = c.skills[e], s = a.skills[e]?.value || 0, r = i.attribute, n = a.attributes[r]?.value || 2, o = t.bonus || 0, u = `2d10 + ${n} + ${s} + ${o}`, m = new Roll(u);
    return await m.evaluate(), await this._createRollMessage(m, {
      title: `${game.i18n.localize(i.label)} (${game.i18n.localize(c.attributes[r])})`,
      targetNumber: t.targetNumber
    }), m;
  }
  /**
   * Roll initiative
   */
  async rollInitiative() {
    const a = `1d10 + ${this.system.derived.initiative || 4}`, i = new Roll(a);
    return await i.evaluate(), i;
  }
  /**
   * Create a formatted chat message for a roll
   */
  async _createRollMessage(e, t) {
    const a = e.total || 0, i = t.targetNumber || 11;
    let s = "failure", r = "Failure";
    const n = a - i;
    n >= 10 ? (s = "critical-success", r = "Critical Success!") : n >= 5 ? (s = "exceptional-success", r = "Exceptional Success") : n >= 0 ? (s = "success", r = "Success") : n >= -5 ? (s = "failure", r = "Failure") : (s = "critical-failure", r = "Critical Failure!");
    const o = `
      <div class="um-roll-card">
        <h3>${t.title}</h3>
        <div class="roll-result ${s}">
          <span class="total">${a}</span>
          <span class="vs">vs TN ${i}</span>
          <span class="result-text">${r}</span>
        </div>
        <div class="roll-details">
          <span class="formula">${e.formula}</span>
          <span class="dice">${e.dice.map((u) => u.results.map((m) => m.result).join(", ")).join(" + ")}</span>
        </div>
      </div>
    `;
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: o,
      roll: e,
      type: CONST.CHAT_MESSAGE_STYLES.OTHER
    });
  }
  /**
   * Apply damage to the actor
   */
  async applyDamage(e, t = {}) {
    const a = this.system, i = a.derived.health.value, s = Math.max(0, i - e);
    await this.update({
      "system.derived.health.value": s
    });
    const r = t.type || "lethal";
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="um-damage-notice">${this.name} takes ${e} ${r} damage${t.location ? ` to the ${t.location}` : ""}. (${s}/${a.derived.health.max} HP)</div>`
    });
  }
  /**
   * Apply mental damage
   */
  async applyMentalDamage(e) {
    const t = this.system, a = t.derived.mentalHealth.value, i = Math.max(0, a - e);
    await this.update({
      "system.derived.mentalHealth.value": i
    }), ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="um-damage-notice">${this.name} takes ${e} mental damage. (${i}/${t.derived.mentalHealth.max} Mental Health)</div>`
    });
  }
  /**
   * Add corruption points
   */
  async addCorruption(e, t = "physical") {
    const a = this.system, i = a.corruption[t].value, s = a.corruption[t].threshold, r = i + e;
    await this.update({
      [`system.corruption.${t}.value`]: r
    }), r >= s && ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="um-corruption-warning">${this.name} has exceeded their ${t} corruption threshold! An affliction may manifest...</div>`
    });
  }
}
class p extends Item {
  /**
   * Prepare base data
   */
  prepareBaseData() {
    super.prepareBaseData();
  }
  /**
   * Prepare derived data
   */
  prepareDerivedData() {
    super.prepareDerivedData();
    const e = this;
    switch (e.type) {
      case "weapon":
        this._prepareWeaponData(e.system);
        break;
      case "armor":
        this._prepareArmorData(e.system);
        break;
    }
  }
  /**
   * Prepare weapon-specific data
   */
  _prepareWeaponData(e) {
    e.damage = e.damage || "1d10", e.damageType = e.damageType || "lethal", e.range = e.range || 0, e.rof = e.rof || 1, e.capacity = e.capacity || 0, e.currentAmmo = e.currentAmmo ?? e.capacity, e.skill = e.skill || "melee", e.qualities = e.qualities || [];
  }
  /**
   * Prepare armor-specific data
   */
  _prepareArmorData(e) {
    e.protection = e.protection || 0, e.coverage = e.coverage || [], e.penalty = e.penalty || 0;
  }
  /**
   * Roll this item (for weapons, this is an attack roll)
   */
  async roll() {
    const e = this;
    if (!this.actor) {
      ui.notifications?.warn("This item is not owned by an actor.");
      return;
    }
    switch (e.type) {
      case "weapon":
        await this._rollWeaponAttack();
        break;
      default:
        await this._showItemCard();
        break;
    }
  }
  /**
   * Roll a weapon attack
   */
  async _rollWeaponAttack() {
    const e = this, t = this.actor, a = e.system, i = a.skill || "melee", s = c.skills[i];
    if (!s) {
      ui.notifications?.error(`Unknown skill: ${i}`);
      return;
    }
    const r = s.attribute, n = t.system.attributes[r]?.value || 2, o = t.system.skills[i]?.value || 0, u = `2d10 + ${n} + ${o}`, m = new Roll(u);
    await m.evaluate();
    const h = await renderTemplate("systems/unhallowed-metropolis/templates/chat/weapon-roll.hbs", {
      actor: t,
      item: this,
      roll: m,
      total: m.total,
      damage: a.damage,
      damageType: a.damageType,
      range: a.range,
      isRanged: a.weaponType === "ranged",
      ammo: a.currentAmmo,
      capacity: a.capacity
    });
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: t }),
      content: h,
      roll: m,
      type: CONST.CHAT_MESSAGE_STYLES.OTHER
    }), a.weaponType === "ranged" && a.currentAmmo > 0 && await this.update({
      "system.currentAmmo": a.currentAmmo - 1
    });
  }
  /**
   * Roll damage for this weapon
   */
  async rollDamage() {
    const e = this;
    if (e.type !== "weapon")
      return null;
    const t = e.system.damage || "1d10", a = new Roll(t);
    return await a.evaluate(), await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      flavor: `${this.name} - Damage`,
      content: `
        <div class="um-damage-roll">
          <span class="damage-total">${a.total}</span>
          <span class="damage-type">${e.system.damageType || "lethal"}</span>
        </div>
      `,
      roll: a,
      type: CONST.CHAT_MESSAGE_STYLES.OTHER
    }), a;
  }
  /**
   * Show an item description card in chat
   */
  async _showItemCard() {
    const e = this, t = `
      <div class="um-item-card">
        <header class="card-header">
          <img src="${this.img}" alt="${this.name}" width="36" height="36"/>
          <h3>${this.name}</h3>
        </header>
        <div class="card-content">
          ${e.system.description || "<p>No description available.</p>"}
        </div>
      </div>
    `;
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: t,
      type: CONST.CHAT_MESSAGE_STYLES.OTHER
    });
  }
  /**
   * Reload a ranged weapon
   */
  async reload() {
    const e = this;
    e.type !== "weapon" || e.system.weaponType !== "ranged" || (await this.update({
      "system.currentAmmo": e.system.capacity
    }), ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: `<div class="um-reload-notice">${this.actor?.name} reloads their ${this.name}.</div>`
    }));
  }
}
class f extends ItemSheet {
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["unhallowed-metropolis", "sheet", "item"],
      width: 520,
      height: 480,
      tabs: [
        { navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }
      ],
      resizable: !0
    });
  }
  /**
   * Return the correct template based on item type
   */
  get template() {
    return `systems/unhallowed-metropolis/templates/items/${this.item.type}-sheet.hbs`;
  }
  getData(e) {
    const t = super.getData(e);
    t.config = c;
    const a = this.item;
    switch (t.system = a.system, t.flags = a.flags, a.type) {
      case "weapon":
        t.skills = this._getWeaponSkills(), t.damageTypes = c.damageTypes, t.weaponTypes = c.weaponTypes;
        break;
      case "armor":
        t.hitLocations = c.hitLocations;
        break;
      case "affliction":
        t.severityLevels = c.afflictionSeverity;
        break;
    }
    return t;
  }
  /**
   * Get list of skills that can be used for weapons
   */
  _getWeaponSkills() {
    return {
      melee: game.i18n.localize("UM.Skills.Melee"),
      brawl: game.i18n.localize("UM.Skills.Brawl"),
      firearms: game.i18n.localize("UM.Skills.Firearms"),
      athletics: game.i18n.localize("UM.Skills.Athletics")
      // For thrown weapons
    };
  }
  activateListeners(e) {
    super.activateListeners(e), this.isEditable;
  }
}
function v() {
  Hooks.on("combatStart", async (l) => {
    console.log("UM | Combat started");
  }), Hooks.on("preCreateCombatant", (l, e, t, a) => {
    const i = l.actor;
    i && (i.system?.derived?.initiative, l.updateSource({ initiative: null }));
  });
}
(() => {
  try {
    const l = globalThis;
    if (typeof l.io == "object" && (typeof l.io.default == "function" ? (l.io = l.io.default, console.log("UM | Normalized window.io from default export")) : typeof l.io.io == "function" && (l.io = l.io.io, console.log("UM | Normalized window.io from nested `io` property"))), typeof l.io == "function" && typeof l.io.connect != "function")
      try {
        l.io.connect = l.io;
      } catch {
      }
  } catch {
  }
})();
Hooks.once("init", async () => {
  console.log("UM | Initializing Unhallowed Metropolis System"), game.unhallowedMetropolis = {
    UMActor: d,
    UMItem: p,
    config: c
  }, CONFIG.Actor.documentClass = d, CONFIG.Item.documentClass = p, game.settings.register("unhallowed-metropolis", "corruptionTracking", {
    name: "UM.Settings.CorruptionTracking",
    hint: "UM.Settings.CorruptionTrackingHint",
    scope: "world",
    config: !0,
    default: !0,
    type: Boolean
  }), game.settings.register("unhallowed-metropolis", "automaticDegrees", {
    name: "UM.Settings.AutomaticDegrees",
    hint: "UM.Settings.AutomaticDegreesHint",
    scope: "world",
    config: !0,
    default: !0,
    type: Boolean
  }), await M(), w(), v(), Actors.unregisterSheet("core", ActorSheet), Actors.registerSheet("unhallowed-metropolis", b, {
    types: ["character"],
    makeDefault: !0,
    label: "UM.SheetLabels.Character"
  }), Actors.registerSheet("unhallowed-metropolis", g, {
    types: ["npc"],
    makeDefault: !0,
    label: "UM.SheetLabels.NPC"
  }), Actors.registerSheet("unhallowed-metropolis", y, {
    types: ["animate", "vampire", "creature"],
    makeDefault: !0,
    label: "UM.SheetLabels.Creature"
  }), Items.unregisterSheet("core", ItemSheet), Items.registerSheet("unhallowed-metropolis", f, {
    makeDefault: !0,
    label: "UM.SheetLabels.Item"
  });
});
Hooks.once("ready", async () => {
  console.log("UM | Unhallowed Metropolis System Ready"), console.log("UM | Welcome to Neo-Victorian London. The dead walk, and the living hide behind walls of brass and steel.");
});
async function M() {
  const l = [
    // Actor sheets
    "systems/unhallowed-metropolis/templates/actors/character-sheet.hbs",
    "systems/unhallowed-metropolis/templates/actors/npc-sheet.hbs",
    "systems/unhallowed-metropolis/templates/actors/creature-sheet.hbs",
    // Item sheets
    "systems/unhallowed-metropolis/templates/items/weapon-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/armor-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/equipment-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/quality-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/affliction-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/disorder-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/talent-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/calling-sheet.hbs",
    "systems/unhallowed-metropolis/templates/items/psychicPower-sheet.hbs",
    // Chat templates
    "systems/unhallowed-metropolis/templates/chat/roll-card.hbs",
    "systems/unhallowed-metropolis/templates/chat/weapon-roll.hbs",
    // Dialog templates
    "systems/unhallowed-metropolis/templates/dialogs/roll-dialog.hbs"
  ];
  return loadTemplates(l);
}
function w() {
  Handlebars.registerHelper("times", function(l, e) {
    let t = "";
    for (let a = 0; a < l; a++)
      t += e.fn({ index: a, first: a === 0, last: a === l - 1 });
    return t;
  }), Handlebars.registerHelper("corruptionPips", function(l, e) {
    let t = "";
    for (let a = 0; a < e; a++) {
      const i = a < l ? "filled" : "empty";
      t += `<span class="corruption-pip ${i}" data-index="${a}"></span>`;
    }
    return new Handlebars.SafeString(t);
  }), Handlebars.registerHelper("attributeDots", function(l, e = 5) {
    let t = "";
    for (let a = 1; a <= e; a++) {
      const i = a <= l ? "filled" : "empty";
      t += `<span class="attribute-dot ${i}" data-value="${a}"></span>`;
    }
    return new Handlebars.SafeString(t);
  }), Handlebars.registerHelper("eq", function(l, e) {
    return l === e;
  }), Handlebars.registerHelper("gt", function(l, e) {
    return l > e;
  }), Handlebars.registerHelper("lt", function(l, e) {
    return l < e;
  }), Handlebars.registerHelper("add", function(l, e) {
    return l + e;
  }), Handlebars.registerHelper("subtract", function(l, e) {
    return l - e;
  });
}
