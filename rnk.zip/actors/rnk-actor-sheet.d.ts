export declare class RnkActorSheet extends ActorSheet {
    static get defaultOptions(): any;
    getData(options?: any): any;
    activateListeners(html: JQuery): void;
}
